"""
Jackson Webster
Room Reservation Backend
Moffat Bay Lodge
"""

from flask import Flask, request, send_from_directory
import mysql.connector

app = Flask(__name__)

@app.route("/")
def home():
    return send_from_directory(".", "reservation.html")

@app.route("/reservation.css")
def css():
    return send_from_directory(".", "reservation.css")

@app.route("/reservation", methods=["POST"])
def reservation():

    room_id = request.form["roomID"]
    num_guests = request.form["numGuests"]
    check_in = request.form["checkInDate"]
    check_out = request.form["checkOutDate"]
    special_requests = request.form["specialRequests"]
    
    connection = mysql.connector.connect(
        host="localhost",
        port=3309,
        user="root",
        password="",
        database="MoffatBay"
    )

    cursor = connection.cursor()

    # Temporary customer until login is implemented
    customer_id = 1

    # Get room price
    cursor.execute(
        "SELECT price FROM Room WHERE roomID = %s",
        (room_id,)
    )

    room = cursor.fetchone()

    if room is None:
        cursor.close()
        connection.close()
        return "Error: Invalid room selected."

    room_price = room[0]

    # Calculate number of nights
    cursor.execute(
        "SELECT DATEDIFF(%s, %s)",
        (check_out, check_in)
    )

    nights = cursor.fetchone()[0]

    if nights <= 0:
        cursor.close()
        connection.close()
        return "Error: Check-out date must be after check-in."

    total_price = room_price * nights

    sql = """
    INSERT INTO Reservation
    (customerID,
     roomID,
     checkInDate,
     checkOutDate,
     numGuests,
     reservationDate,
     totalPrice,
     reservationStatus,
     specialRequests)
    VALUES
    (%s,%s,%s,%s,%s,NOW(),%s,'Confirmed',%s)
    """

    values = (
        customer_id,
        room_id,
        check_in,
        check_out,
        num_guests,
        total_price,
        special_requests
    )

    cursor.execute(sql, values)

    connection.commit()

    cursor.close()
    connection.close()

    return "Reservation Successful!"

if __name__ == "__main__":
    app.run(debug=True)