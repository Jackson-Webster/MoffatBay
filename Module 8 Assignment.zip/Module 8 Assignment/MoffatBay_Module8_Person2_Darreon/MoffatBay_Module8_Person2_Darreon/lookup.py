"""
Darreon Tolen
Reservation Lookup Backend
Moffat Bay Lodge - Module 8

This program uses Python's built-in web server and SQLite database.
Guests can search by reservation ID or email address.
"""
from __future__ import annotations

import html
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs

APP_DIR = Path(__file__).resolve().parent
DATABASE = APP_DIR / "moffat_bay.db"
HOST = "127.0.0.1"
PORT = 5000


def get_connection() -> sqlite3.Connection:
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database() -> None:
    with get_connection() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS reservations (
                reservation_id INTEGER PRIMARY KEY,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                email TEXT NOT NULL,
                room_type TEXT NOT NULL,
                guests INTEGER NOT NULL,
                check_in TEXT NOT NULL,
                check_out TEXT NOT NULL,
                status TEXT NOT NULL
            )
            """
        )
        connection.execute(
            """
            INSERT OR IGNORE INTO reservations
            (reservation_id, first_name, last_name, email, room_type,
             guests, check_in, check_out, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (1001, "Darreon", "Tolen", "darreon@example.com", "Queen",
             2, "July 15, 2026", "July 18, 2026", "Confirmed"),
        )
        connection.execute(
            """
            INSERT OR IGNORE INTO reservations
            (reservation_id, first_name, last_name, email, room_type,
             guests, check_in, check_out, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (1002, "Kimberly", "Orozco", "kimberly@example.com", "King",
             2, "August 10, 2026", "August 13, 2026", "Confirmed"),
        )


def find_reservations(reservation_id: str, email_address: str) -> list[sqlite3.Row]:
    with get_connection() as connection:
        if reservation_id:
            return connection.execute(
                "SELECT * FROM reservations WHERE reservation_id = ?",
                (reservation_id,),
            ).fetchall()
        return connection.execute(
            "SELECT * FROM reservations WHERE LOWER(email) = LOWER(?)",
            (email_address,),
        ).fetchall()


def page_html(reservations=None, error="", reservation_id="", email_address="") -> str:
    reservations = reservations or []
    result_html = ""
    if error:
        result_html = f'<div class="message error" role="alert">{html.escape(error)}</div>'
    elif reservations:
        cards = []
        for reservation in reservations:
            cards.append(f"""
            <div class="reservation-card">
                <p><strong>Reservation ID:</strong> {reservation['reservation_id']}</p>
                <p><strong>Guest:</strong> {html.escape(reservation['first_name'])} {html.escape(reservation['last_name'])}</p>
                <p><strong>Email:</strong> {html.escape(reservation['email'])}</p>
                <p><strong>Room Type:</strong> {html.escape(reservation['room_type'])}</p>
                <p><strong>Guests:</strong> {reservation['guests']}</p>
                <p><strong>Check-In:</strong> {html.escape(reservation['check_in'])}</p>
                <p><strong>Check-Out:</strong> {html.escape(reservation['check_out'])}</p>
                <p><strong>Status:</strong> {html.escape(reservation['status'])}</p>
            </div>
            """)
        result_html = '<section id="results" class="results"><h2>Reservation Results</h2>' + "".join(cards) + "</section>"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation Lookup | Moffat Bay Lodge</title>
    <link rel="stylesheet" href="/style.css">
</head>
<body>
    <nav>
        <a href="/index.html">Home</a>
        <a href="/">Reservation Lookup</a>
    </nav>
    <main class="lookup-container">
        <h1>Reservation Lookup</h1>
        <p>Enter either your reservation ID or the email address used when the reservation was created.</p>
        <form method="post" action="/" class="lookup-form">
            <label for="reservation_id">Reservation ID:</label>
            <input id="reservation_id" name="reservation_id" type="text" value="{html.escape(reservation_id)}" placeholder="Example: 1001">
            <p class="or-text">OR</p>
            <label for="email">Email Address:</label>
            <input id="email" name="email" type="email" value="{html.escape(email_address)}" placeholder="Example: darreon@example.com">
            <button type="submit">Search</button>
        </form>
        {result_html}
    </main>
</body>
</html>"""


class LookupHandler(BaseHTTPRequestHandler):
    def send_bytes(self, content: bytes, content_type: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def do_GET(self) -> None:
        if self.path == "/" or self.path.startswith("/?"):
            self.send_bytes(page_html().encode("utf-8"), "text/html; charset=utf-8")
            return
        filename = self.path.lstrip("/")
        file_path = (APP_DIR / filename).resolve()
        if APP_DIR not in file_path.parents or not file_path.is_file():
            self.send_bytes(b"File not found", "text/plain; charset=utf-8", 404)
            return
        content_type = "text/css" if file_path.suffix == ".css" else "text/html; charset=utf-8"
        self.send_bytes(file_path.read_bytes(), content_type)

    def do_POST(self) -> None:
        if self.path != "/":
            self.send_bytes(b"Not found", "text/plain; charset=utf-8", 404)
            return
        length = int(self.headers.get("Content-Length", "0"))
        values = parse_qs(self.rfile.read(length).decode("utf-8"))
        reservation_id = values.get("reservation_id", [""])[0].strip()
        email_address = values.get("email", [""])[0].strip()

        error = ""
        reservations = []
        if not reservation_id and not email_address:
            error = "Enter a reservation ID or email address."
        elif reservation_id and not reservation_id.isdigit():
            error = "Reservation ID must contain numbers only."
        else:
            reservations = find_reservations(reservation_id, email_address)
            if not reservations:
                error = "No reservation was found with that information."

        content = page_html(reservations, error, reservation_id, email_address).encode("utf-8")
        self.send_bytes(content, "text/html; charset=utf-8")

    def log_message(self, format: str, *args) -> None:
        print(f"{self.address_string()} - {format % args}")


def run_server() -> None:
    initialize_database()
    server = ThreadingHTTPServer((HOST, PORT), LookupHandler)
    print(f"Reservation Lookup running at http://{HOST}:{PORT}")
    print("Press Ctrl+C to stop the server.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    run_server()
